#!/usr/bin/env bash

echo un-taring git...
tar xf git-2.4.3.tar -C /tmp/
echo un-tarred.
